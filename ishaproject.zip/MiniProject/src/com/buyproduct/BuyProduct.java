package com.buyproduct;

import java.sql.SQLException;

public interface BuyProduct {
	public void Shoppingcart()throws SQLException;
}
