package com.checkquntity;

import java.sql.SQLException;

public interface CheckQuantity {
	public	void userinput();
	
	public void jdbc() throws SQLException, ClassNotFoundException;
	
	
}
