package com.calculatebill;

import java.sql.SQLException;

public interface Calculatebill {
	public void calculate() throws SQLException, ClassNotFoundException;
}
