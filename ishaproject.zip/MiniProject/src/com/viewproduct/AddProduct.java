package com.viewproduct;

public interface AddProduct {
	public void add();
}
