package com.guest;

import java.sql.SQLException;

public interface ViewProduct {
	public  void productInput();
	
	public  void ProductCheck() throws SQLException, ClassNotFoundException;
}
