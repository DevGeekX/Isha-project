package com.displayamount;

import java.sql.SQLException;

public interface DisplyAm {
		public void amount() throws ClassNotFoundException, SQLException;
}
