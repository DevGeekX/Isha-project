package com.purchaseitem;

public interface Purchase {
	public void Shoppingcart();
}
