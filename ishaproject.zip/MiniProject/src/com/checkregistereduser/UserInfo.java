package com.checkregistereduser;

import java.sql.SQLException;

public interface UserInfo {
	public void userInput();
   public void jdbc() throws SQLException, ClassNotFoundException;
}
